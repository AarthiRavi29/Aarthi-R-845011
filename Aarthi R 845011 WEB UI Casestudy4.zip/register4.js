function validation(){
	var name=document.register.name.value;
	var password=document.register.password.value;
	var password1=document.register.password1.value;
	var num1=document.register.num1.value;
	var num2=document.register.num2.value;
	if (name==null || name=="") {
		alert("name cant be empty");
		return false;
	}
	if (password.length<6 || password.length>8){
		alert("password should be minimum of 7 character maximum of 8 character");
		return false;
	}
	if (password1.length<6 || password1.length>8){
		alert("password should be minimum of 7 character maximum of 8 character");
		return false;
	}
	if(num1==null || num1.length<10){
		alert("mobile contact information is mandatory,Give valid contact number");
		return false;
		
	}
	if(num2.length<10){
		alert("Give valid contact number");
		return false;
		
	}
	
}