function resetof(){
	 alert("do you want to reset");
       document.getElementByForm("registerform").reset();
}
function validation(){
	var name=document.registerform.name.value;
	var password=document.registerform.password.value;
	var num1=document.registerform.num1.value;
	var type=document.registerform.type.value;
	if (name==null || name=="") {
		alert("name cant be empty");
		return false;
	}
	if (password.length<6 || password.length>8){
		alert("password should be minimum of 7 character maximum of 8 character");
		return false;
	}
	if(num1==null || num1.length<10){
		alert("mobile contact information is mandatory,Give valid contact number");
		return false;
		
	}
	if(type=="select"){
		alert("please select the applytype");
		return false;
	}
}
